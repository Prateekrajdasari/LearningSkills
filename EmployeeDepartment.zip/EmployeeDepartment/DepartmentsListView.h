//
//  DepartmentsListView.h
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/25/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Department;

@interface DepartmentsListView : UIView
@end
