//
//  AddEditViewController.h
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Department;

@interface AddEditViewController : UIViewController <UIPopoverControllerDelegate>
{
    UIPopoverController *popOver;
}


@property (nonatomic, retain) NSDate *joinDate;
@property (nonatomic, retain) Department *deptName;


@property (weak, nonatomic) IBOutlet UIButton *dateButton;
@property (weak, nonatomic) IBOutlet UIButton *departmentButton;

@property (weak, nonatomic) IBOutlet UITextField *nameTextField;
@property (weak, nonatomic) IBOutlet UITextField *ageTextField;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

- (IBAction)closeTheDetailsWindow:(id)sender;
- (IBAction)openPopOver:(id)sender;

-(void)closeThePopOver;

@end
