//
//  AddEditViewController.m
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import "AddEditViewController.h"
#import "DatePickerController.h"
#import "DepartmentTableController.h"
#import "Department.h"
#import "Employee.h"

@interface AddEditViewController ()

@end

@implementation AddEditViewController


- (id)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

-(void)setJoinDate:(NSDate *)joinDate
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateStyle:NSDateFormatterMediumStyle];
    
    [_dateButton setTitle:[formatter stringFromDate:joinDate] forState:UIControlStateNormal];
    
    _joinDate = joinDate;
}

-(void)setDeptName:(Department *)deptName
{
    [_departmentButton setTitle:deptName.deptname forState:UIControlStateNormal];
    
    _deptName = deptName;
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone
                                                                                 target:self
                                                                                 action:@selector(saveEmployee:)];
    self.navigationItem.rightBarButtonItem = rightButton;
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)openPopOver:(id)sender {
    
    UIButton *tempButton = (UIButton *)sender;
    
    if ([tempButton tag] == 0) {
        
        DatePickerController *datePicker = [[DatePickerController alloc] init];
        
        datePicker.delegate = self;
        
        popOver = [[UIPopoverController alloc] initWithContentViewController:datePicker];
        
        popOver.popoverContentSize = CGSizeMake(320, 260);
        
        popOver.delegate = self;
        
        [popOver presentPopoverFromRect:tempButton.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }else{
    
        DepartmentTableController *deptController = [[DepartmentTableController alloc] init];
        
        deptController.delegate = self;
        deptController.deptManagedObjectContext = _managedObjectContext;
        
        popOver = [[UIPopoverController alloc] initWithContentViewController:deptController];
        
        popOver.popoverContentSize = CGSizeMake(320, 375);
        
        [popOver presentPopoverFromRect:tempButton.frame inView:self.view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
    }
}

- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController {
	// If a popover is dismissed, set the last button tapped to nil.
	
}

-(void)closeThePopOver
{
    [popOver dismissPopoverAnimated:YES];
}

-(void)saveEmployee:(id)sender
{
    Employee *emp = [NSEntityDescription insertNewObjectForEntityForName:@"Employee" inManagedObjectContext:_managedObjectContext];
    
    emp.name = _nameTextField.text;
    emp.joindate = _joinDate;
    emp.age = [NSNumber numberWithInt:[_ageTextField.text intValue]];
    emp.department = _deptName;
    
    NSError *error;
    
    if (![_managedObjectContext save:&error]) {
        
        NSLog(@"Error Occured due to %@", [error userInfo]);
    }

    [self.navigationController popViewControllerAnimated:YES];
}






@end
