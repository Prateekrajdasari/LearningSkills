//
//  DatePickerController.h
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DatePickerController : UIViewController
{
    UIDatePicker *datePicker;
}

@property (nonatomic, retain) id delegate;

@end
