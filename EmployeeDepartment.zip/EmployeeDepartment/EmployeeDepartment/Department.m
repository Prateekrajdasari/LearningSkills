//
//  Department.m
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import "Department.h"
#import "Employee.h"


@implementation Department

@dynamic deptname;
@dynamic employees;

@end
