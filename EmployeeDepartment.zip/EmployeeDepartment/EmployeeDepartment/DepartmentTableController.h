//
//  DepartmentTableController.h
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import <UIKit/UIKit.h>

@class Department;

@interface DepartmentTableController : UIViewController<UITableViewDataSource, UITableViewDelegate>
{

    NSArray *deptArray;

    Department *selectedDept;
}


@property (nonatomic, retain) id delegate;
@property (strong, nonatomic) IBOutlet UITableView *departmentsTableView;

@property (nonatomic, retain) IBOutlet UIView *myViewFromNib;
@property (strong, nonatomic) IBOutlet UITextField *addNewDeptTextField;

@property (nonatomic, retain) NSManagedObjectContext *deptManagedObjectContext;
- (IBAction)closeTheWindow:(id)sender;
- (IBAction)addNewDepartment:(id)sender;

@end
