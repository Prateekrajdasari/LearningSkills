//
//  DepartmentTableController.m
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import "DepartmentTableController.h"
#import "Department.h"

@interface DepartmentTableController ()

@end

@implementation DepartmentTableController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    [self updateDataArray];
    
    _myViewFromNib = [[NSBundle mainBundle] loadNibNamed:@"DepartmentsListUI" owner:self options:nil][0];
    
    [self.view addSubview:_myViewFromNib];

}


-(void)updateDataArray
{
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    
    NSEntityDescription *description = [NSEntityDescription entityForName:@"Department" inManagedObjectContext:self.deptManagedObjectContext];
    
    [request setEntity:description];
    
    NSError *error = nil;
    
    deptArray = [self.deptManagedObjectContext executeFetchRequest:request error:&error];
    
    [_departmentsTableView reloadData];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [deptArray count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell)
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
    
    if (deptArray[indexPath.row]) {
     
        Department *deptCellName = (Department*)deptArray[indexPath.row];
        
        cell.textLabel.text = deptCellName.deptname;
        
        NSLog(@"%@",deptCellName.deptname);
    }
    
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [_departmentsTableView  cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO animated:YES];
    
    if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        
        cell.accessoryType = UITableViewCellAccessoryNone;
        
        selectedDept = nil;
        
    }else{
    
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        
        selectedDept = (Department *)[deptArray objectAtIndex:indexPath.row];
    }
}

-(void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell * cell = [_departmentsTableView  cellForRowAtIndexPath:indexPath];
    [cell setSelected:NO animated:YES];
    
    if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
}


- (IBAction)closeTheWindow:(id)sender {
    
    if ([(UIButton*)sender tag] == 1) {
        
        [self.delegate setValue:selectedDept forKey:@"deptName"];
    }
    
    if ([self.delegate canPerformAction:@selector(closeThePopOver) withSender:nil])
        [self.delegate performSelector:@selector(closeThePopOver)];

}

- (IBAction)addNewDepartment:(id)sender {
    
    Department *description = [NSEntityDescription insertNewObjectForEntityForName:@"Department" inManagedObjectContext:self.deptManagedObjectContext];
    
    description.deptname = [_addNewDeptTextField text];
    
    NSError *error = nil;
    
    if (![self.deptManagedObjectContext save:&error]) {
        
        NSLog(@"error occured during department insertion %@",[error localizedDescription]);
    }else{
        
        NSLog(@"New department Succefully added");
        
        [self updateDataArray];
    }
    
    
    [_addNewDeptTextField setText:@""];

}
@end
