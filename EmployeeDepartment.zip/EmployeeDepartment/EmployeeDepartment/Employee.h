//
//  Employee.h
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Department;

@interface Employee : NSManagedObject

@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSDate * joindate;
@property (nonatomic, retain) NSNumber * age;
@property (nonatomic, retain) Department *department;

@end
