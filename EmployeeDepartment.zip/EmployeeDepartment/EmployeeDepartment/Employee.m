//
//  Employee.m
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import "Employee.h"
#import "Department.h"


@implementation Employee

@dynamic name;
@dynamic joindate;
@dynamic age;
@dynamic department;

@end
