//
//  RootViewController.h
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
{

    NSArray *employeeDataArray;
    NSArray *departmentDataArray;
}


@property (strong, nonatomic) IBOutlet UITableView *employeesTableview;
@property (strong, nonatomic) IBOutlet UITableView *departmentTableview;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

- (IBAction)addEmployee:(id)sender;


@end
