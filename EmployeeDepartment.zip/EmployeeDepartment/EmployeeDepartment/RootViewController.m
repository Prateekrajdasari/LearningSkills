//
//  RootViewController.m
//  EmployeeDepartment
//
//  Created by Prateek Raj Dasari on 7/24/13.
//  Copyright (c) 2013 Prateek Raj Dasari. All rights reserved.
//

#import "RootViewController.h"
#import "AddEditViewController.h"
#import "Employee.h"
#import "Department.h"

@interface RootViewController ()

@end

@implementation RootViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
        UIBarButtonItem *rightButton = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd
                                                                                     target:self
                                                                                     action:@selector(addEmployee:)];
        self.navigationItem.rightBarButtonItem = rightButton;
    }
    return self;
}

-(void)viewDidAppear:(BOOL)animated
{
    NSError *error = nil;
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    
    NSEntityDescription *empEntity = [NSEntityDescription entityForName:@"Employee" inManagedObjectContext:self.managedObjectContext];
    
    [request setEntity:empEntity];
    
    employeeDataArray = [_managedObjectContext executeFetchRequest:request error:&error];
    
    [_employeesTableview reloadData];
    
    NSEntityDescription *deptDescription = [NSEntityDescription entityForName:@"Department" inManagedObjectContext:_managedObjectContext];
    
    [request setEntity:deptDescription];
    
    departmentDataArray = [_managedObjectContext executeFetchRequest:request error:&error];
    
    [_departmentTableview reloadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.navigationController.title = @"Employees";
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addEmployee:(id)sender {
    
    AddEditViewController *addEditViewController = [[AddEditViewController alloc] init];
    
    addEditViewController.managedObjectContext = self.managedObjectContext;
    
    self.navigationController.title = @"Add Employee.";
    
    [self.navigationController pushViewController:addEditViewController animated:YES];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView == _employeesTableview) {
        
        return 1;
    }else{
    
        return [departmentDataArray count];
    }
}

-(NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
    if (tableView == _departmentTableview)
    return [departmentDataArray[section] valueForKey:@"deptname"];
    
    return @"Employees";
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == _employeesTableview) {
        
        return [employeeDataArray count];
    }else{
    
        Department *dept = departmentDataArray[section];
        
        NSArray *array = [dept.employees allObjects];
        
        return [array count];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == _employeesTableview) {
        
        NSString *cellIdentifer = @"EmployeeCell";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifer];
        
        if (!cell)
            cell = [[UITableViewCell alloc] init];
        
        Employee *emp = employeeDataArray[indexPath.row];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateStyle:NSDateFormatterMediumStyle];
        
        cell.textLabel.text = [NSString stringWithFormat:@"Date: %@ Name: %@ Age: %@ Department: %@",[formatter stringFromDate:emp.joindate], emp.name, emp.age,emp.department.deptname];
        
        return cell;
    }else{
    
        NSString *cellIdentifer = @"DepartmentCell";
        
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifer];
        
        if (!cell)
            cell = [[UITableViewCell alloc] init];
        
        Department *dept = departmentDataArray[indexPath.section];
        
        NSArray *tempArray = [dept.employees allObjects];
        
        Employee *emp = tempArray[indexPath.row];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateStyle:NSDateFormatterMediumStyle];
        
        cell.textLabel.text = [NSString stringWithFormat:@"Date: %@ Name: %@ Age: %@",[formatter stringFromDate:emp.joindate], emp.name, emp.age];
        
        return cell;
    }
}












































@end
